__turbopack_load_page_chunks__("/_app", [
  "static/chunks/f214f9b3b8667acf.js",
  "static/chunks/aa72697b8ab8a311.js",
  "static/chunks/turbopack-042c7528ea68730c.js"
])
