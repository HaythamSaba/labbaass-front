var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/[...nextauth]/route.js")
R.c("server/chunks/[root-of-the-server]__bf174954._.js")
R.c("server/chunks/[root-of-the-server]__ac9929f1._.js")
R.m(43433)
R.m(60237)
module.exports=R.m(60237).exports
