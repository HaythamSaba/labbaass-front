__turbopack_load_page_chunks__("/_error", [
  "static/chunks/60f348638bc97787.js",
  "static/chunks/aa72697b8ab8a311.js",
  "static/chunks/turbopack-744e1035c5e56c31.js"
])
