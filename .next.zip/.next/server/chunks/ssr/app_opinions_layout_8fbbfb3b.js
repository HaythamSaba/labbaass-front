module.exports=[99964,a=>{"use strict";a.s(["default",()=>e]);var b=a.i(7997),c=a.i(5120),d=a.i(54802);let e=function({children:a}){return(0,b.jsxs)("section",{className:"bg-[#FAFAFA]",children:[(0,b.jsx)(d.default,{}),a,(0,b.jsx)(c.default,{})]})}}];

//# sourceMappingURL=app_opinions_layout_8fbbfb3b.js.map