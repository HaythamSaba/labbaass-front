module.exports=[74656,a=>{"use strict";a.s(["default",()=>e]);var b=a.i(7997),c=a.i(5120),d=a.i(54802);let e=function({children:a}){return(0,b.jsxs)("section",{children:[(0,b.jsx)(d.default,{}),a,(0,b.jsx)(c.default,{})]})}}];

//# sourceMappingURL=app_clinics_layout_68b9101b.js.map