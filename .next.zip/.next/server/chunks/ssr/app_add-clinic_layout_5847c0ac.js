module.exports=[62570,a=>{"use strict";a.s(["default",()=>e]);var b=a.i(7997),c=a.i(5120),d=a.i(54802);let e=function({children:a}){return(0,b.jsxs)("section",{className:"bg-[#FAFAFA]",children:[(0,b.jsx)(d.default,{}),a,(0,b.jsx)(c.default,{})]})}}];

//# sourceMappingURL=app_add-clinic_layout_5847c0ac.js.map