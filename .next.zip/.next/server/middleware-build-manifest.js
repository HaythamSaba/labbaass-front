globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/f214f9b3b8667acf.js",
      "static/chunks/aa72697b8ab8a311.js",
      "static/chunks/turbopack-042c7528ea68730c.js"
    ],
    "/_error": [
      "static/chunks/60f348638bc97787.js",
      "static/chunks/aa72697b8ab8a311.js",
      "static/chunks/turbopack-744e1035c5e56c31.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/4afcb71094b6b40f.js",
    "static/chunks/522518d740397639.js",
    "static/chunks/e6e396fa420200fe.js",
    "static/chunks/c19da6693934fea1.js",
    "static/chunks/2008ffcf9e5b170c.js",
    "static/chunks/turbopack-ddf0306e9250c8ca.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];